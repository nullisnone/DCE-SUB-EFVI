/* SPDX-License-Identifier: GPL-2.0 OR BSD-2-Clause */
/* X-SPDX-Copyright-Text: (c) Copyright 2017-2019 Xilinx, Inc. */
int ci_check_net_namespace(const char* ns_filename);
int ci_switch_net_namespace(const char* ns_filename);
